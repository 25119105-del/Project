print('=== HỆ THỐNG TÍNH TOÁN GIAO DỊCH XĂNG RON 95-V ===')
#Chương trình 1: Nhập vào giá tiền cần đổ xăng 
Gia_Niem_Yet = 21.510 #ấn định giá 1 lít xăng RON 95-V
tien_xang = float(input('Bạn muốn đổ bao nhiêu tiền xăng? (nghìn VNĐ) ')) #Nhập số tiền cần đổ xăng
xang = round((tien_xang/Gia_Niem_Yet),2) #Tính lượng xăng tương ứng và làm tròn 2 chữ số 
print(f'Lượng xăng tương ứng là: {xang} (lít)')

print('-------------------------------------------------')

#Chương trình 2: Nhập số lít xăng muốn đổ
luong_xang = float(input('Bạn muốn đổ bao nhiêu lít xăng? (lít) ')) #Nhập số lít xăng muốn đổ
gia = round((luong_xang*Gia_Niem_Yet),2) #Tính số tiền tương ứng và làm tròn 2 chữ số
print(f'Số tiền tương ứng chính xác bạn cần phải trả là: {gia} (nghìn VNĐ)')
