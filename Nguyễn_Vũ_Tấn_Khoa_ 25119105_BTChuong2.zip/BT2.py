print('-'*75)
print('=== HỆ THỐNG TÍNH TOÁN GIAO DỊCH XĂNG RON 95-V ĐỐI VỚI NGOẠI TỆ (USD) ===')
print('-'*75)

#Giá trị hằng số
Gia_Xang_Niem_Yet = 21.510
Ty_Gia_USD_VNĐ = 25.540

#Chương trình 1: Nhập vào số tiền cần đổ xăng
Tri_Gia_USD_Tieu_Thu = float(input('Bạn muốn đổ bao nhiêu tiền xăng? (USD) ')) #Nhập số tiền bạn muốn dùng để đổ xăng
Doi_VNĐ = round(Tri_Gia_USD_Tieu_Thu*Ty_Gia_USD_VNĐ,2) #Đổi sang VNĐ
Luong_Xang = round((Doi_VNĐ/Gia_Xang_Niem_Yet),2) #Lượng xăng tương ứng với số tiền trên
print('='*3)
print(f'Với {Tri_Gia_USD_Tieu_Thu} (USĐ) tương ứng với {Doi_VNĐ} (nghìn VNĐ)')
print(f'Lượng xăng bạn nhận được tương ứng là: {Luong_Xang} (lít)')

print('='*75)
#Chương trình 2: Nhập vào số xăng cần đổ 
Luong_xang_can_thiet = float(input('Bạn cần đổ bao nhiêu lít xăng? (lít) ')) #Nhập lượng xăng bạn muốn đổ
Xang_VNĐ = round(Luong_xang_can_thiet* Gia_Xang_Niem_Yet,2) #Đổi xem bao nhiêu tiền VNĐ
Doi_USD = round(Xang_VNĐ/Ty_Gia_USD_VNĐ,2) #Đổi từ VNĐ sang USD
print('='*10)
print(f'{Luong_xang_can_thiet} (lít) tương đương với {Xang_VNĐ} (nghìn VNĐ)')
print(f'{Luong_xang_can_thiet} (lít) cần tiêu {Doi_USD} (USD)')
