def giai_thua(n):
    if n == 0:
        return 1
    return n*giai_thua(n-1)
S = 0 
t = 0
for i in range(3,100,2):
    t += 1/float(giai_thua(i))
S = float(1.0/t)
print(f'kết quả phép tính là: {S}')