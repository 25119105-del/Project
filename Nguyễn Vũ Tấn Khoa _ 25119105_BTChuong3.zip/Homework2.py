#Excercise 3.1
import math
m = int(input("Nhập m (m < n) : "))
n = int(input("Nhập n (n > m) : "))
i = 0
j = 0 
for i in range(m,n+1): #cho vòng lặp i chạy từ m đến n
    if i < 2: 
        continue #nếu i<2 thì k có số nguyên tố nên bỏ qua lượt i này 
    else: 
        for j in range(2,int(math.sqrt(i))+1): #cho vòng lặp j chạy từ 2 đến căn bậc 2 của i
            if i%j == 0: 
                break #thoát vòng lặp
        else:
            print(f'{i} là số nguyên tố trong khoảng [{m},{n}]')
            
#Excercise 2
i = 1
n = int(input('Nhập số nguyên n: '))
print('Các số chính phương trong khoảng trên bao gồm: ')
#biết số chính phương là số mà có căn bậc 2 là 1 số nguyên, nên có thể thấy nếu 1 số nguyên bình phương thì kết quả
#chính là 1 số chính phương
while  i*i <= n:   
    print(f'{i*i}', end=" ") #sử dụng lệnh end in trên 1 hàng
    i += 1 # tăng i lên 1 đơn vị
