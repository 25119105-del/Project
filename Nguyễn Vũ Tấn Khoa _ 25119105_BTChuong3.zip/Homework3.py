#Homework 3.1
n = int(input('Nhập một số nguyên n (n>0) : '))
So_dao_nguoc = 0
for _ in range(len(str(n))):
    So_cuoi = n%10
    So_dao_nguoc = So_dao_nguoc*10 + So_cuoi
    n //= 10
print(f'Số đảo ngược là: {So_dao_nguoc}')
    

#Homework 3.2
n = int(input('Nhập một số nguyên (n>0) : '))
doi = str(n) #đổi từ kiểu int sang string sử dụng để duyệt chuỗi
S = 0
for i in range(len(doi)): #vòng lặp for bắt đầu từ 0, với bước nhảy là 1
    S += int(doi[i]) #Cộng dồn các giá trị được duyệt trong chuỗi vào tổng S
print(f'Tổng các chữ số của số đã nhập là: {S}')

#Homework 3.3
n = int(input('Nhập số nguyên n (n>0): '))
count = 0
if n == 0: 
    count = 1
else:
    while n > 0:
        n //= 10 #chia 10 để xét 1 số cuối
        count += 1 #cộng biến count thêm 1 đơn vị
print(f"Số nhập ban đầu có {count} chữ số.")

#Homework 3.4
import math #thêm thư viện để sử dụng phép tính căn bậc 2 (sqrt)
n = int(input('Nhập số nguyên n (n>0): '))
i = 1
if n < 2: 
    print(f'{n} không phải số nguyên tố')
elif n == 2:
    print(f'{n} là số nguyên tố')
else:
    while i <= math.sqrt(n): #chỉ xét cho đến khi i nhỏ hơn hoặc bằng căn bậc 2 của n 
        i += 1 #tăng i lên 1 đơn vị
        if n%i == 0:
            print(f'{n} không phải số nguyên tố') 
            break #dừng chương trình
        elif i == (n-1):
            print(f'{n} là số nguyên tố')
            break
         