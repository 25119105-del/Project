#Excercise 2.1
S = 0 
n = 0 
while S <= 50:
    n += 1 # tăng n lên 1 đơn vị
    S += n # cộng dồn tổng S 
print(f'Giá trị S cuối cùng là: {S}')
print(f'Số nguyên n cuối cùng làm tổng S vượt quá 50 là: {n}')

#Excercise 2.2
m = int(input('Nhập số nguyên dương m: '))
n = int(input('Nhập số nguyên dương n: '))
i = 0
# Thấy rằng cho 2 số nguyên, UCLN sẽ nằm trong khoảng 1 đến số nhỏ hơn 
min_value = min(m,n)
for i in range(min_value, 0, -1): #cho i chạy từ giá trị nhỏ hơn trong 2 số đến 0, với bước nhảy lùi 1
    if m%i == 0 and n%i == 0: #Tìm giá trị lớn nhất mà cả 2 có thể cùng chia hết
        print(f'Ước chung lớn nhất giữa {m} và {n} là: {i}')
        break #thoát vòng lặp
            